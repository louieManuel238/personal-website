(function($){
  $(function(){

    $('.sidenav').sidenav();
    $('.project-img').parallax();
    $('.modal').modal();
    $('.slider').slider();
  }); // end of document ready
})(jQuery); // end of jQuery name space
 